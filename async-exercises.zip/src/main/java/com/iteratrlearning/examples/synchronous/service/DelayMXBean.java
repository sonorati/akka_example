package com.iteratrlearning.examples.synchronous.service;

public interface DelayMXBean
{
    long getDelayInMs();

    void setDelayInMs(final long delay);
}
