package com.iteratrlearning.examples.actors.akkabasics;

import akka.event.Logging;
import akka.event.LoggingAdapter;

public class SimpleActorLive {

    //private LoggingAdapter log = Logging.getLogger(getContext().system(), this);
}
