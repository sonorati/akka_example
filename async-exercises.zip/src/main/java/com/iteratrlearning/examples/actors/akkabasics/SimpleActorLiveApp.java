package com.iteratrlearning.examples.actors.akkabasics;

public class SimpleActorLiveApp {
    public static void main(String[] args) {

    }
}

